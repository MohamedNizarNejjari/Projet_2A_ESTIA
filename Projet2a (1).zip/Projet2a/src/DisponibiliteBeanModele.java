

public class DisponibiliteBeanModele {
	private int id;
	private String date;
	private String jour;
	private String hre;
	
	public DisponibiliteBeanModele() {}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getJour() {
		return jour;
	}

	public void setJour(String jour) {
		this.jour = jour;
	}

	public String getHre() {
		return hre;
	}

	public void setHre(String hre) {
		this.hre = hre;
	}


}
