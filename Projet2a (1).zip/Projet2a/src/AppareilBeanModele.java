
public class AppareilBeanModele {
	private int id;
	private String nom;
	private int nombre;
	private int puissance;
	private int niveaubatterie;
	private int dureeutilisation;
	
	public AppareilBeanModele() {}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getNombre() {
		return nombre;
	}

	public void setNombre(int nombre) {
		this.nombre = nombre;
	}

	public int getPuissance() {
		return puissance;
	}

	public void setPuissance(int puissance) {
		this.puissance = puissance;
	}

	public int getNiveaubatterie() {
		return niveaubatterie;
	}

	public void setNiveaubatterie(int niveaubatterie) {
		this.niveaubatterie = niveaubatterie;
	}

	public int getDureeutilisation() {
		return dureeutilisation;
	}

	public void setDureeutilisation(int dureeutilisation) {
		this.dureeutilisation = dureeutilisation;
	}
	

}
